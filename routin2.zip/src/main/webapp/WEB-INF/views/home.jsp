<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head><title>홈</title></head>
<body>
<h2>로그인 성공! 홈 페이지입니다.</h2>
</body>
</html>
