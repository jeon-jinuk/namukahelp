<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>로그인</title>
</head>
<body>
<h2>로그인</h2>

<form method="post" action="/login">
    <label>아이디: <input type="text" name="username" /></label><br/>
    <label>비밀번호: <input type="password" name="password" /></label><br/>
    <button type="submit">로그인</button>
</form>

<!-- 로그인 실패 메시지 -->
<c:if test="${param.error eq 'true'}">
    <p style="color:red;">아이디 또는 비밀번호가 잘못되었습니다.</p>
</c:if>
</body>
</html>
