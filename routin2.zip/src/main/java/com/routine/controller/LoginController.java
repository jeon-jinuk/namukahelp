package com.routine.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/loginForm")
    public String loginForm() {
        return "login"; // → templates/login.html
    }

    @GetMapping("/")
    public String home() {
        return "home";
    }
}
