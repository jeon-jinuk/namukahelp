package com.routine.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/circle")
public class CirclePageController {

    @GetMapping("/create")
    public String showCreatePage() {
        return "circle/create"; // templates/circle/create.html
    }
    @GetMapping("/list")
    public String showCircleListPage() {
        return "circle/list";
    }
    @GetMapping("/my")
    public String showMyCirclesPage() {
        return "circle/my";
    }


}
