package com.routine.domain.b_circle.service;

import com.routine.domain.a_member.model.Member;
import com.routine.domain.a_member.model.Role;
import com.routine.domain.a_member.repository.MemberRepository;
import com.routine.domain.b_circle.dto.CircleCreateRequestDto;
import com.routine.domain.b_circle.model.Circle;
import com.routine.domain.b_circle.model.CircleMember;
import com.routine.domain.b_circle.repository.CircleMemberRepository;
import com.routine.domain.b_circle.repository.CircleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CircleServiceImpl implements CircleService {

    private final CircleRepository circleRepository;
    private final MemberRepository memberRepository;
    private final CircleMemberRepository circleMemberRepository;

    @Override
    public void createCircle(CircleCreateRequestDto dto, Long creatorId) {
        // 써클 이름 중복 체크
        if (circleRepository.existsByName(dto.getName())) {
            throw new IllegalArgumentException("이미 존재하는 써클 이름입니다.");
        }

        // 써클 생성
        Circle circle = Circle.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .tags(dto.getTags())
                .isPublic(dto.isPublic())
                .creatorId(creatorId)
                .build();

        circleRepository.save(circle);

        // 써클 생성자를 자동으로 써클장으로 등록
        Member creator = memberRepository.findById(creatorId)
                .orElseThrow(() -> new IllegalArgumentException("사용자가 존재하지 않습니다."));

        CircleMember leader = CircleMember.builder()
                .circle(circle)
                .member(creator)
                .role(CircleMember.Role.LEADER)
                .status(CircleMember.Status.APPROVED)
                .commitRate(0.0)
                .skipCount(0)
                .points(0)
                .build();

        circle.getMembers().add(leader);
        creator.getCircleMembers().add(leader);

        circleMemberRepository.save(leader);
    }



    @Override
    public void joinCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        boolean alreadyJoined = circle.getMembers().stream()
                .anyMatch(cm -> cm.getMember().getId().equals(memberId));
        if (alreadyJoined) {
            throw new IllegalStateException("이미 가입한 그룹입니다.");
        }

        CircleMember circleMember = CircleMember.builder()
                .circle(circle)
                .member(member)
                .role(CircleMember.Role.MEMBER)
                .status(CircleMember.Status.APPROVED)
                .commitRate(0.0)
                .skipCount(0)
                .points(0)
                .build();

        circle.getMembers().add(circleMember);
        member.getCircleMembers().add(circleMember);

        circleMemberRepository.save(circleMember);
    }

    // 써클 수정 (생성자 or ADMIN만 가능)
    @Override
    public void updateCircle(Long circleId, Long memberId, CircleCreateRequestDto dto) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        if (!circle.getCreatorId().equals(memberId) && member.getRole() != Role.ADMIN) {
            throw new SecurityException("수정 권한이 없습니다.");
        }

        circle.setName(dto.getName());
        circle.setDescription(dto.getDescription());
        circle.setTags(dto.getTags());
        circle.setPublic(dto.isPublic());

        circleRepository.save(circle);
    }

    // 써클 삭제 (생성자 or ADMIN만 가능)
    @Override
    public void deleteCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        if (!circle.getCreatorId().equals(memberId) && member.getRole() != Role.ADMIN) {
            throw new SecurityException("삭제 권한이 없습니다.");
        }

        circleRepository.delete(circle);
    }
    @Override
    public Circle findCircleById(Long circleId) {
        return circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));
    }
    @Override
    public List<Circle> findAllCircles() {
        return circleRepository.findAll();
    }

    @Override
    public List<Circle> findCirclesByMemberId(Long memberId) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        System.out.println("✅ 현재 로그인한 사용자 ID: " + member.getId());
        System.out.println("✅ 가입된 써클 수: " + member.getCircleMembers().size());

        for (CircleMember cm : member.getCircleMembers()) {
            System.out.println("🌀 써클 ID: " + cm.getCircle().getId());
            System.out.println("🌀 써클 이름: " + cm.getCircle().getName());
            System.out.println("🌀 상태: " + cm.getStatus());
        }

        return member.getCircleMembers().stream()
                .filter(cm -> cm.getStatus() == CircleMember.Status.APPROVED)
                .map(CircleMember::getCircle)
                .collect(Collectors.toList());
    }

    @Override
    public void leaveCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));

        CircleMember circleMember = circle.getMembers().stream()
                .filter(cm -> cm.getMember().getId().equals(memberId))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("가입하지 않은 써클입니다."));

        circle.getMembers().remove(circleMember);
        circleMember.getMember().getCircleMembers().remove(circleMember);

        circleMemberRepository.delete(circleMember);
    }
    @Override
    public void approveCircleMember(Long circleId, Long memberId, Long approverId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("써클이 존재하지 않습니다."));

        Member approver = memberRepository.findById(approverId)
                .orElseThrow(() -> new IllegalArgumentException("사용자가 존재하지 않습니다."));

        if (!circle.getCreatorId().equals(approverId) && approver.getRole() != Role.ADMIN) {
            throw new SecurityException("승인 권한이 없습니다.");
        }

        CircleMember member = circle.getMembers().stream()
                .filter(cm -> cm.getMember().getId().equals(memberId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("해당 사용자는 써클에 가입하지 않았습니다."));

        member.setStatus(CircleMember.Status.APPROVED);
        circleMemberRepository.save(member);
    }
    @Override
    public List<CircleMember> getMembersInCircle(Long circleId, Long requesterId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));

        Member requester = memberRepository.findById(requesterId)
                .orElseThrow(() -> new IllegalArgumentException("사용자가 존재하지 않습니다."));

        if (!circle.getCreatorId().equals(requesterId) && requester.getRole() != Role.ADMIN) {
            throw new SecurityException("열람 권한이 없습니다.");
        }

        return circle.getMembers().stream()
                .filter(cm -> cm.getStatus() == CircleMember.Status.APPROVED)
                .collect(Collectors.toList());
    }
    @Override
    public void rejectCircleMember(Long circleId, Long memberId, Long adminId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));

        Member admin = memberRepository.findById(adminId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 관리자입니다."));

        // 관리자 또는 써클 생성자만 거절 가능
        if (!circle.getCreatorId().equals(adminId) && admin.getRole() != Role.ADMIN) {
            throw new SecurityException("승인/거절 권한이 없습니다.");
        }

        CircleMember targetMember = circle.getMembers().stream()
                .filter(cm -> cm.getMember().getId().equals(memberId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("해당 멤버는 써클에 존재하지 않습니다."));

        targetMember.setStatus(CircleMember.Status.REJECTED);
        circleMemberRepository.save(targetMember);
    }
    @Override
    public void transferLeadership(Long circleId, Long currentLeaderId, Long newLeaderId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));

        Member currentLeader = memberRepository.findById(currentLeaderId)
                .orElseThrow(() -> new IllegalArgumentException("현재 사용자를 찾을 수 없습니다."));

        Member newLeader = memberRepository.findById(newLeaderId)
                .orElseThrow(() -> new IllegalArgumentException("새 리더를 찾을 수 없습니다."));

        if (!circle.getCreatorId().equals(currentLeaderId) && currentLeader.getRole() != Role.ADMIN) {
            throw new SecurityException("써클장 권한이 없습니다.");
        }


        CircleMember target = circle.getMembers().stream()
                .filter(cm -> cm.getMember().getId().equals(newLeaderId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("해당 멤버는 써클에 소속되어 있지 않습니다."));

        circle.setCreatorId(newLeaderId);
        target.setRole(CircleMember.Role.LEADER);

        circleRepository.save(circle);
        circleMemberRepository.save(target);
    }
    @Override
    public List<Circle> searchCircles(Boolean isPublic, String keyword) {
        if (isPublic != null && keyword != null && !keyword.isEmpty()) {
            return circleRepository.findByIsPublicAndTagsContaining(isPublic, keyword);
        } else if (isPublic != null) {
            return circleRepository.findByIsPublic(isPublic);
        } else if (keyword != null && !keyword.isEmpty()) {
            return circleRepository.findByTagsContaining(keyword);
        } else {
            return circleRepository.findAll();
        }
    }







}





