package com.routine.domain.a_member.service;

import com.routine.domain.a_member.dto.SignupRequestDto;
import java.util.List;
import com.routine.domain.a_member.model.Member;



public interface MemberService {
    void registerMember(SignupRequestDto dto);
    void updateMember(Long memberId, SignupRequestDto dto);
    void deleteMember(Long memberId);

    List<Member> findAllMembers();


}
