package com.routine.domain.b_circle.service;

import com.routine.domain.a_member.model.Member;
import com.routine.domain.a_member.model.Role;
import com.routine.domain.a_member.repository.MemberRepository;
import com.routine.domain.b_circle.dto.CircleCreateRequestDto;
import com.routine.domain.b_circle.model.Circle;
import com.routine.domain.b_circle.model.CircleMember;
import com.routine.domain.b_circle.repository.CircleMemberRepository;
import com.routine.domain.b_circle.repository.CircleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CircleServiceImpl implements CircleService {

    private final CircleRepository circleRepository;
    private final MemberRepository memberRepository;
    private final CircleMemberRepository circleMemberRepository;

    @Override
    public void createCircle(CircleCreateRequestDto dto, Long creatorId) {
        Circle circle = Circle.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .tags(dto.getTags())
                .isPublic(dto.isPublic())
                .creatorId(creatorId)
                .build();

        circleRepository.save(circle);
    }

    @Override
    public void joinCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        boolean alreadyJoined = circle.getMembers().stream()
                .anyMatch(cm -> cm.getMember().getId().equals(memberId));
        if (alreadyJoined) {
            throw new IllegalStateException("이미 가입한 그룹입니다.");
        }

        CircleMember circleMember = CircleMember.builder()
                .circle(circle)
                .member(member)
                .role(CircleMember.Role.MEMBER)
                .commitRate(0.0)
                .skipCount(0)
                .points(0)
                .build();

        circle.getMembers().add(circleMember);
        member.getCircleMembers().add(circleMember);

        circleMemberRepository.save(circleMember);
    }

    // 써클 수정 (생성자 or ADMIN만 가능)
    @Override
    public void updateCircle(Long circleId, Long memberId, CircleCreateRequestDto dto) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        if (!circle.getCreatorId().equals(memberId) && member.getRole() != Role.ADMIN) {
            throw new SecurityException("수정 권한이 없습니다.");
        }

        circle.setName(dto.getName());
        circle.setDescription(dto.getDescription());
        circle.setTags(dto.getTags());
        circle.setPublic(dto.isPublic());

        circleRepository.save(circle);
    }

    // 써클 삭제 (생성자 or ADMIN만 가능)
    @Override
    public void deleteCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 그룹입니다."));

        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        if (!circle.getCreatorId().equals(memberId) && member.getRole() != Role.ADMIN) {
            throw new SecurityException("삭제 권한이 없습니다.");
        }

        circleRepository.delete(circle);
    }
    @Override
    public Circle findCircleById(Long circleId) {
        return circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));
    }
    @Override
    public List<Circle> findAllCircles() {
        return circleRepository.findAll();
    }

    @Override
    public List<Circle> findCirclesByMemberId(Long memberId) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 사용자입니다."));

        return member.getCircleMembers().stream()
                .map(CircleMember::getCircle)
                .collect(Collectors.toList());
    }
    @Override
    public void leaveCircle(Long circleId, Long memberId) {
        Circle circle = circleRepository.findById(circleId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 써클입니다."));

        CircleMember circleMember = circle.getMembers().stream()
                .filter(cm -> cm.getMember().getId().equals(memberId))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("가입하지 않은 써클입니다."));

        circle.getMembers().remove(circleMember);
        circleMember.getMember().getCircleMembers().remove(circleMember);

        circleMemberRepository.delete(circleMember);
    }


}





