package com.routine.domain.b_circle.service;

import com.routine.domain.b_circle.dto.CircleCreateRequestDto;
import java.util.List;
import com.routine.domain.b_circle.model.Circle;


public interface CircleService {


    void createCircle(CircleCreateRequestDto dto, Long creatorId);
    void joinCircle(Long circleId, Long memberId);
    void updateCircle(Long circleId, Long memberId, CircleCreateRequestDto dto);
    void deleteCircle(Long circleId, Long memberId);
    void leaveCircle(Long circleId, Long memberId);


    List<Circle> findAllCircles();

    List<Circle> findCirclesByMemberId(Long memberId);

    Circle findCircleById(Long circleId);

}
