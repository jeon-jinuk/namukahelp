package com.routine.domain.b_circle.model;

import com.routine.domain.a_member.model.Member;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class CircleInvitation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Circle circle;

    @ManyToOne
    private Member invitedMember;

    private boolean used = false;

    private LocalDateTime invitedAt = LocalDateTime.now();
}
