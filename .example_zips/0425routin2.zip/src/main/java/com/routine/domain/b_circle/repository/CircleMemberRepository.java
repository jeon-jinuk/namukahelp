package com.routine.domain.b_circle.repository;

import com.routine.domain.b_circle.model.CircleMember;
import com.routine.domain.b_circle.model.CircleMember.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CircleMemberRepository extends JpaRepository<CircleMember, Long> {


    List<CircleMember> findByCircleId(Long circleId);

    List<CircleMember> findByMemberId(Long memberId);

    boolean existsByCircleIdAndMemberId(Long circleId, Long memberId);

    List<CircleMember> findByCircleIdAndRole(Long circleId, Role role);

    List<CircleMember> findByMemberIdAndRole(Long memberId, Role role);

    long countByCircleId(Long circleId);

    boolean existsByCircleIdAndMemberIdAndRole(Long circleId, Long memberId, CircleMember.Role role);



}
