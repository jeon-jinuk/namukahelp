package com.routine.domain.b_circle.service;

import com.routine.domain.b_circle.model.Circle;
import com.routine.domain.a_member.model.Member;
import com.routine.domain.b_circle.model.CircleInvitation;
import com.routine.domain.b_circle.repository.CircleInvitationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CircleInvitationService {

    private final CircleInvitationRepository invitationRepository;

    public void invite(Member invitedMember, Circle circle) {
        CircleInvitation invitation = new CircleInvitation();
        invitation.setCircle(circle);
        invitation.setInvitedMember(invitedMember);
        invitationRepository.save(invitation);
    }

    public boolean hasValidInvitation(Member member, Circle circle) {
        return invitationRepository.existsByCircleAndInvitedMemberAndUsedFalse(circle, member);
    }

    public void markInvitationUsed(Member member, Circle circle) {
        invitationRepository.findByCircleAndInvitedMemberAndUsedFalse(circle, member)
                .ifPresent(inv -> {
                    inv.setUsed(true);
                    invitationRepository.save(inv);
                });
    }
    public List<CircleInvitation> getPendingInvitations(Long memberId) {
        return invitationRepository.findByInvitedMemberIdAndUsedFalse(memberId);
    }

}
