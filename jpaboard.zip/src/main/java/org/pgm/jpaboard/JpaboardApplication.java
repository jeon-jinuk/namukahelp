package org.pgm.jpaboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(JpaboardApplication.class, args);
    }

}
