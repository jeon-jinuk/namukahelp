package com.example.securityboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
