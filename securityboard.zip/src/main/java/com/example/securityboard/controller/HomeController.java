package com.example.securityboard.controller;


import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Log4j2
public class HomeController {
    @GetMapping("/")
    public String home(){
        log.info("home");
        return "index";
    }
    @GetMapping("/admin")
    public void exAdmin() {

        log.info("exAdmin");
    }
}
