package com.example.securityboard.service;

import com.example.securityboard.domain.BoardEntity;
import com.example.securityboard.dto.BoardDTO;
import com.example.securityboard.dto.PageRequestDTO;
import com.example.securityboard.dto.PageResponseDTO;
import com.example.securityboard.repository.BoardRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Log4j2
public class BoardServiceImpl implements BoardService {
    @Autowired
    private BoardRepository boardRepository;

    @Override
    public void registerBoard(BoardDTO boardDTO) {
        BoardEntity boardEntity = dtoToEntity(boardDTO);
        boardRepository.save(boardEntity);
    }

    @Override
    public BoardDTO readBoard(Long bno) {
        //BoardEntity boardEntity=boardRepository.findById(bno)
        BoardEntity boardEntity=boardRepository.findByIdWithImages(bno)
                .orElse(null);
        boardEntity.updateReadcount();
        boardRepository.save(boardEntity);
        return entityToDto(boardEntity);
    }

    @Override
    public void updateBoard(BoardDTO boardDTO) {
        BoardEntity boardEntity = boardRepository.findById(boardDTO.getBno()).get();
        boardEntity.change(boardDTO.getTitle(), boardDTO.getContent());
        boardEntity.clearImages();
        if(boardDTO.getFileNames()!=null) {
            for (String fileName : boardDTO.getFileNames()) {
                String[] arr=fileName.split("_");
                boardEntity.addImage(arr[0], arr[1]);
            }
        }
        boardRepository.save(boardEntity);
    }

    @Override
    public void deleteBoard(Long bno) {
        boardRepository.deleteById(bno);
    }

    @Override
    public PageResponseDTO<BoardDTO> list(PageRequestDTO pageRequestDTO) {
        Pageable pageable = pageRequestDTO.getPageable("bno");
        Page<BoardEntity> result = boardRepository.searchAll(
                pageRequestDTO.getTypes(),
                pageRequestDTO.getKeyword(),
                pageable);
        List<BoardDTO> dtoList = result.stream()
                .map(boardEntity -> entityToDto(boardEntity))
                .collect(Collectors.toList());

        return PageResponseDTO.<BoardDTO>withAll()
                .pageRequestDTO(pageRequestDTO)
                .dtoList(dtoList)
                .total((int) result.getTotalElements())
                .build();
    }
}
