async function addReply(replyObj){
    const response=await axios.post(`/replies/`,replyObj)
    console.log(response)
    return response.data
}
async function getReply(rno){
    const response=await axios.get(`/replies/${rno}`)
    return response.data
}
async function modifyReply(replyObj){
    const response=await axios.put(`/replies/${replyObj.rno}`,replyObj)
    return response.data
}
async function removeReply(rno){
    const response=await axios.delete(`/replies/${rno}`)
    return response.data
}
async function getList({bno, page, size, goLast}){
    console.log(page)
    const response=await axios.get(`/replies/list/${bno}`,{params:{page,size}})
    if(goLast){
        const total=response.data.total
        const lastPage=parseInt(Math.ceil(total/size))
        return getList({bno:bno, page:lastPage, size:size})
    }
    return response.data
}