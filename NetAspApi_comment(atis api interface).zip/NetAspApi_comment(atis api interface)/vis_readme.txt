=============================
기록
-- SKOH1/2동  Edge PC Inspection 대응 API 모듈 (Ntels 와 규격 매칭)
=============================

-- ~240810
1. 엔텔스 규격서에 맞춰 내용 최종 정리
-- 241113
1. 엔텔스 규격서에 맞춰 기능 추가
   - Return값 모두 대문자 치환
   - ROI 별 Threshold 추가
   - Process 탐지 기능 추가 (Edge Inspection, Viss_Upload, Db_upload 프로세스 실행중인지 감지해서 return)