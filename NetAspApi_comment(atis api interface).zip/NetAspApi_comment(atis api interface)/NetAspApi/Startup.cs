﻿// ASP.NET Core의 필수 구성 요소들을 가져옵니다.
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using NetAspApi.Class;         // 사용자 정의 클래스 (예: UppercaseNamingPolicy, StatusChecker 등)
using Serilog;                // Serilog 로깅 라이브러리

public class Startup
{
    // IConfiguration을 통해 appsettings.json 등의 설정을 주입받음
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    // 의존성 주입 및 서비스 등록
    public void ConfigureServices(IServiceCollection services)
    {
        // 컨트롤러 + JSON 직렬화 옵션 설정
        services.AddControllers().AddJsonOptions(options =>
        {
            // JSON의 속성 이름을 사용자 정의 정책 (대문자 정책 등)으로 설정
            options.JsonSerializerOptions.PropertyNamingPolicy = new UppercaseNamingPolicy();
        });

        // Swagger(OpenAPI) 문서 자동 생성 등록
        services.AddSwaggerGen(c => //수정사항
        {
            c.SwaggerDoc("v1", new OpenApiInfo { Title = "NetAspApi", Version = "v1" });
            c.CustomSchemaIds(t => t.FullName); 
        });

        // Serilog를 사용한 로깅 구성
        services.AddLogging(builder =>
        {
            builder.AddSerilog(dispose: true);
        });

        // StatusChecker 클래스 DI 등록 (임시 수명, 요청마다 인스턴스 생성)
        services.AddTransient<StatusChecker>();

        // CORS(교차 출처 리소스 공유) 설정 - 모든 출처, 메서드, 헤더 허용
        services.AddCors(options =>
        {
            options.AddDefaultPolicy(builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            });
        });
    }

    // HTTP 요청 파이프라인 설정
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        // 개발 환경일 경우 개발자 예외 페이지 및 Swagger UI 활성화
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage(); // 개발용 상세 에러 페이지
            app.UseSwagger();                // Swagger JSON 생성
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1")); // Swagger UI 경로 설정
        }

        // Serilog를 통한 HTTP 요청 로깅 활성화
        app.UseSerilogRequestLogging();

        // CORS 정책 적용
        app.UseCors();

        // 라우팅 활성화
        app.UseRouting();

        // 인증/인가 미들웨어 (Authorization만 사용 중, Authentication은 없음)
        app.UseAuthorization();

        // 컨트롤러 엔드포인트 매핑
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers(); // [ApiController] 속성이 있는 클래스 자동 매핑
        });
    }
}
