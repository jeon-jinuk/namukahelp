
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.WindowsServices;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;
using System.Runtime.InteropServices;
using NetAspApi.Class;
using NetAspApi.Controllers;
using NetAspApi;
using static System.Net.Mime.MediaTypeNames;

public class Program
{
    public static async Task Main(string[] args)
    {
        // ���� ���
        Environment.SetEnvironmentVariable("PROGRAM_DIR", AppContext.BaseDirectory);

        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .CreateLogger();

        configCheck();

        // �۾� ���丮 ����
        //if (IsRunningAsAService())
        Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);

        //Log.Information("service :: "+ WindowsServiceHelpers.IsWindowsService());

        try
        {
            Log.Information("Starting up the web host");
            var host = CreateHostBuilder(args).Build();

            if (WindowsServiceHelpers.IsWindowsService())
            {
                await host.RunAsync();
            }
            else
            {
                await host.RunAsync();
            }
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Host terminated unexpectedly");
        }
        finally
        {
            Log.CloseAndFlush();
        }
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseSerilog((context, services, configuration) => configuration
            .ReadFrom.Configuration(context.Configuration)
            .ReadFrom.Services(services)
            .Enrich.FromLogContext()) // Use Serilog
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            })
        .UseWindowsService(); // Windows ���񽺷� ȣ���� ����

    // Helper class to check if running as Windows Service
    private static bool IsRunningAsAService()
    {
        // Check if running on Windows and as a service
        return RuntimeInformation.IsOSPlatform(OSPlatform.Windows) &&
               !Environment.UserInteractive &&
               Environment.CurrentDirectory == @"C:\Windows\system32";
    }

    private static void configCheck()
    {
        try
        {
            var iniPath = Path.Combine(Environment.GetEnvironmentVariable("PROGRAM_DIR"), "config.ini");

            if (!new FileInfo(iniPath).Exists)
            {
                using (StreamWriter sw = new StreamWriter(iniPath))
                {
                    sw.Flush();
                    sw.Close();
                }

                IniFile.SetValue(iniPath, "SETTING", "CONN_TIME", "3000");  // ������ �ð� (Time Out)
                IniFile.SetValue(iniPath, "SETTING", "RTN_TIME", "3000");  // ������ �ð� (Time Out)
                IniFile.SetValue(iniPath, "SETTING", "RTN_TIME_MODEL", "60000");  // ������ �ð� (Time Out) : Model Change ���� (Ȥ�ó� �; ������ ������)

                IniFile.SetValue(iniPath, "MAPP", "PLC_NET_NM", "PLC");  // PLC Adapter ��Ī
                IniFile.SetValue(iniPath, "MAPP", "CAM_CA_NM", "Cathode");  // Cathode cam Adapter ��Ī
                IniFile.SetValue(iniPath, "MAPP", "CAM_AN_NM", "Anode");  // Anode cam Adapter ��Ī
                IniFile.SetValue(iniPath, "MAPP", "EDGE_PG_NM", "SKON_TabWelldingInspection");  // Edge ���α׷� ��Ī
                IniFile.SetValue(iniPath, "MAPP", "VISS_PG_NM", "VISS_Auto_Upload");  // Viss ���α׷� ��Ī
                IniFile.SetValue(iniPath, "MAPP", "DB_PG_NM", "DB_Auto_Upload");  // DB ���α׷� ��Ī
            }

            SetConfig.connTime = IniFile.GetValue(iniPath, "SETTING", "CONN_TIME", "%");   // ������ �ð� (Time Out)
            SetConfig.rtnTime = IniFile.GetValue(iniPath, "SETTING", "RTN_TIME", "%");    // ������ �ð� (Time Out)
            SetConfig.rtnTimeModel = IniFile.GetValue(iniPath, "SETTING", "RTN_TIME_MODEL", "%");    // ������ �ð� (Time Out) : Model Change ���� (Ȥ�ó� �; ������ ������)

            SetConfig.plcNetNm = IniFile.GetValue(iniPath, "MAPP", "PLC_NET_NM", "PLC");  // PLC Adapter ��Ī
            SetConfig.camCaNm = IniFile.GetValue(iniPath, "MAPP", "CAM_CA_NM", "Cathode");  // Cathode cam Adapter ��Ī
            SetConfig.camAnNm = IniFile.GetValue(iniPath, "MAPP", "CAM_AN_NM", "Anode");  // Anode cam Adapter ��Ī
            SetConfig.edgePgNm = IniFile.GetValue(iniPath, "MAPP", "EDGE_PG_NM", "SKON_TabWelldingInspection");  // Edge ���α׷� ��Ī
            SetConfig.vissPgNm = IniFile.GetValue(iniPath, "MAPP", "VISS_PG_NM", "VISS_Auto_Upload");  // Viss ���α׷� ��Ī
            SetConfig.dbPgNm = IniFile.GetValue(iniPath, "MAPP", "DB_PG_NM", "DB_Auto_Upload");  // DB ���α׷� ��Ī

            if (SetConfig.connTime.Equals("%"))
            {
                SetConfig.connTime = "3000";
                Log.Information("Connection Timeout is Null....  Set Force Value 3s");
            }
            if (SetConfig.rtnTime.Equals("%"))
            {
                SetConfig.rtnTime = "10000";
                Log.Information("Return Timeout is Null....  Set Force Value 10s");
            }
            if (SetConfig.rtnTimeModel.Equals("%"))
            {
                SetConfig.rtnTimeModel = "60000";
                Log.Information("Return Timeout(Model Change) is Null....  Set Force Value 60s");
            }

            Log.Information($"SETTING INFO - [ConnTime : {SetConfig.connTime}] , [RtnTime : {SetConfig.rtnTime}], [RtnTimeModel : {SetConfig.rtnTimeModel}]");
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}



