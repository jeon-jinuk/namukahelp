# Set variables
$ServiceName = "MAXRestAPIService"
$DisplayName = "MAX RestAPI Service"
$BinaryPath = "$PWD\PG\NetAspApi.exe"
$ServiceDescription = "IDMAX RestAPI Background Service for CrackVision Runtime Process."

# Create the service
New-Service -Name $ServiceName `
           -BinaryPathName $BinaryPath `
           -DisplayName $DisplayName `
           -Description $ServiceDescription `
           -StartupType Automatic

# Start the service
Start-Service -Name $ServiceName