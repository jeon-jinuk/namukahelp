using System.Runtime.InteropServices;
using System.Text;

namespace NetAspApi
{
    public class returnData
    {
        public string RESULT_CODE { get; set; }
        public string RESULT_DATA { get; set; }
        public string ERROR_DATA { get; set; }
    }

    public class ThresholdUpdateRequest
    {
        public int Threshold { get; set; }
    }

    public class SetConfig
    {
        public static string connTime { get; set; }     // Runtime PG connection Ÿ�Ӿƿ� �ð�(s)
        public static string rtnTime { get; set; }      // ��ȯ Ÿ�Ӿƿ� �ð�(s)
        public static string rtnTimeModel { get; set; } // ��ȯ Ÿ�Ӿƿ� �ð�(s) : Model Change ����
        public static string plcNetNm { get; set; } // PLC Adapter ��Ī
        public static string camCaNm { get; set; } // Cathode cam Adapter ��Ī
        public static string camAnNm { get; set; } // Anode cam Adapter ��Ī
        public static string edgePgNm { get; set; } // Edge ���α׷� ��Ī
        public static string vissPgNm { get; set; } // Viss ���α׷� ��Ī
        public static string dbPgNm { get; set; } // DB ���α׷� ��Ī
    }

    public class Status
    {
        public IList<string> STATUS_CODE { get; set; }
    }
    
    /// <summary>
    /// Service Status ȣ�� �� ���� �Ǵ� ��ü
    /// API ���� ����
    /// </summary>
    public class service_result
    {
        public string? RESULT_CODE { get; set; }    // Result Code ����
        public string? ERROR_DATA { get; set; }     // Error ����
        public string? PLC_NET_STS { get; set; }    // PLC ��Ʈ��ũ ����
        public string? CAM_CA_NET_STS { get; set; } // Camera ��Ʈ��ũ ���� (Cathode)
        public string? CAM_AN_NET_STS { get; set; } // Camera ��Ʈ��ũ ���� (Anode)
        public string? EDGE_PG_RUN_STS { get; set; }    // Edge Inspection Program Process ����
        public string? VISS_PG_RUN_STS { get; set; }    // Viss Upload Program Process ����
        public string? DB_PG_RUN_STS { get; set; }      // DB UPload Program Process ����
    }

    class IniFile
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        public static void SetValue(string path, string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, path);
        }

        public static string GetValue(string path, string Section, string Key, string Default)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, Default, temp, 255, path);
            if (temp != null && temp.Length > 0) return temp.ToString();
            else return Default;
        }
    }
}
