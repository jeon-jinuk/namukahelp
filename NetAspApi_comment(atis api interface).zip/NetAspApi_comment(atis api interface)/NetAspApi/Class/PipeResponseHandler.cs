﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace NetAspApi.Class
{
    /// <summary>
    /// Pipe 통신 결과를 처리하고 JSON 응답을 생성하는 유틸리티 클래스
    /// </summary>
    public class PipeResponseHandler
    {
        /// <summary>
        /// 객체를 JSON 문자열로 직렬화
        /// Null 값은 포함하지 않음
        /// </summary>
        public string jsonSerialize(object s)
        {
            return JsonConvert.SerializeObject(s, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });
        }

        /// <summary>
        /// 오류 응답을 JSON 문자열로 생성
        /// </summary>
        public string CreateErrorResponse(string resultCode, string errorData)
        {
            return jsonSerialize(new
            {
                RESULT_CODE = FormatResultCode(resultCode),
                ERROR_DATA = errorData
            });
        }

        /// <summary>
        /// 상태 반환용 객체 정의
        /// resultData가 status 형식일 경우 이 클래스로 디시리얼라이즈
        /// </summary>
        public class statusReturn
        {
            public string MDL_FILE_NM { get; set; }
            public string ROI1 { get; set; }
            public string ROI2 { get; set; }
            public string ROI3 { get; set; }
        }

        /// <summary>
        /// 성공 응답을 JSON 문자열로 생성
        /// resultData가 없으면 빈 응답, "status" 형식이면 객체 변환 후 응답
        /// </summary>
        public string CreateSuccessResponse(string resultCode, string resultData = null, string triggerType = null)
        {
            if (string.IsNullOrEmpty(resultData))
            {
                return jsonSerialize(new
                {
                    RESULT_CODE = FormatResultCode(resultCode),
                    ERROR_DATA = string.Empty
                });
            }
            else
            {
                if (triggerType.Equals("status"))
                {
                    return jsonSerialize(new
                    {
                        RESULT_CODE = FormatResultCode(resultCode),
                        RESULT_DATA = JsonConvert.DeserializeObject<statusReturn>(resultData),
                        ERROR_DATA = string.Empty
                    });
                }
                else
                {
                    return jsonSerialize(new
                    {
                        RESULT_CODE = FormatResultCode(resultCode),
                        RESULT_DATA = resultData,
                        ERROR_DATA = string.Empty
                    });
                }
            }
        }

        /// <summary>
        /// 파이프 통신에서 받은 응답 문자열을 파싱하고 JSON 형태로 반환
        /// 응답 형식: "resultCode|data"
        /// </summary>
        public string ParsePipeResponse(string response, string triggerType = null)
        {
            var responseParts = response.Split('|');
            var resultCode = responseParts[0];
            var resultDataOrError = responseParts.Length > 1 ? responseParts[1] : string.Empty;

            switch (resultCode)
            {
                case "0":   // OK
                    if (string.IsNullOrEmpty(resultDataOrError))
                        return CreateSuccessResponse(resultCode);
                    else
                        return CreateSuccessResponse(resultCode, resultDataOrError, triggerType);
                case "11":  // PipeServer 관련 오류메세지 : {ex.Message}
                case "12":  // 다른 작업이 완료전에 또다른 명령이 입력되었을 때 : System is busy
                case "13":  // |로 잘랐을때 파라미터가 2개가 안될때 : Invalid Parameter
                case "14":  // "update_threshold_trigger" 같은 지정된 명령어가 입력되지 않았을 때 : Invalid command
                case "21":  // threshold update중 발생하는 오류 메세지 : {ex.Message}
                case "22":  // { } 사이에 ,로 분리된 값이 한개라도 들어와야 함. : Invalid Parameter
                case "23":  // double 타입이 아닌 값이 입력될 경우 : Invalid value
                case "24":  // 0.0 < threshold < 1.0 : Out of range 
                case "31":  // Model Change중 발생하는 오류 메세지 : {ex.Message}
                case "32":  // 입력 파라미터 오류 : Invalid Parameter
                case "33":  // 파일을 찾을 수 없음 : File not found
                case "41":  // API 서비스 통신 관련  기타 오류 메시지 : {ex.Message}
                case "42":  // 런타임 프로그램 무응답 : Not Response
                case "43":  // 런타임 프로그램과 API 서버간 통신도중 장애시 : Disconnect Runtime
                case "51":  // Status Service Check 오류
                case "52":  // Status Service Check 오류 (Config 오류)
                    return CreateErrorResponse(resultCode, resultDataOrError);
                default:
                    return CreateSuccessResponse(resultCode, resultDataOrError);
            }
        }

        private string FormatResultCode(string code)
        {
            // Convert code to three-digit format with leading zeros
            return code.Equals("0") ? "OK" : $"EC{int.Parse(code):D3}";
        }

        public static bool IsJson(string input)
        {
            // 간단한 JSON 포맷 체크 (시작과 끝이 { }로 되어 있는지)
            return input.StartsWith("{") && input.EndsWith("}");
            //if (string.IsNullOrWhiteSpace(input))
            //{
            //    return false;
            //}
            //
            //input = input.Trim();
            //
            //if ((input.StartsWith("{") && input.EndsWith("}")) || // 객체형 JSON
            //    (input.StartsWith("[") && input.EndsWith("]"))) // 배열형 JSON
            //{
            //    try
            //    {
            //        JToken.Parse(input);
            //        return true;
            //    }
            //    catch (JsonReaderException)
            //    {
            //        return false;
            //    }
            //}
            //
            //return false;
        }

    }
}
