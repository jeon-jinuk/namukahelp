﻿using System.Text.Json;

namespace NetAspApi.Class
{
    /// <summary>
    /// API Respose시, 모든 문자를 Upper case로 해달라는 요청으로 생성된 Upper Case 치환용 클래스
    /// </summary>
    public class UppercaseNamingPolicy : JsonNamingPolicy
    {
        public override string ConvertName(string name)
        {
            return name.ToUpper();
        }
    }
}
