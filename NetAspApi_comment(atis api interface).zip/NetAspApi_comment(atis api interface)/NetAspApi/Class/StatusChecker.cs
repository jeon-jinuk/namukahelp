﻿using System.Diagnostics;
using System.Net.NetworkInformation;

namespace NetAspApi.Class
{
    public class StatusChecker
    {
        private readonly ILogger<StatusChecker> _logger;

        // 생성자에서 ILogger 주입
        public StatusChecker(ILogger<StatusChecker> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// 특정 네트워크의 상태를 확인하고 결과를 반환
        /// </summary>
        /// <param name="adapterName">체크할 네트워크 어댑터 이름</param>
        /// <returns>"ON" 또는 "OFF"</returns>
        public (bool,string) NetworkAdapterChecker(string adapterName)
        {
            try
            {
                var networkAdapter = NetworkInterface.GetAllNetworkInterfaces()
                    .FirstOrDefault(ni => ni.Name.Equals(adapterName, StringComparison.OrdinalIgnoreCase));

                if (networkAdapter != null)
                {
                    //_logger.LogInformation($"Adapter: {networkAdapter.Name}");
                    //_logger.LogInformation($"  Description: {networkAdapter.Description}");
                    //_logger.LogInformation($"  Type: {networkAdapter.NetworkInterfaceType}");
                    //_logger.LogInformation($"  Status: {networkAdapter.OperationalStatus}");
                    //_logger.LogInformation($"  Speed: {networkAdapter.Speed / 1_000_000} Mbps");

                    if (networkAdapter.OperationalStatus == OperationalStatus.Up)
                    {
                        _logger.LogInformation($"{adapterName} Adapter is connected.");
                        return (true,"ON");
                    }
                    else
                    {
                        _logger.LogInformation($"{adapterName} Adapter is not connected.");
                        return (true,"OFF");
                    }
                }
                else
                {
                    _logger.LogInformation($"Adapter with name '{adapterName}' not found.");
                    return (false,"OFF");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error checking Adapter '{adapterName}': {ex.Message}");
                return (false,"OFF");
            }
        }

        /// <summary>
        /// 지정된 프로세스가 실행 중인지 확인하고 결과를 반환
        /// </summary>
        /// <param name="processName">체크할 프로세스 이름 (확장자 .exe 제외)</param>
        /// <returns>"ON" 또는 "OFF"</returns>
        public (bool,string) ProcessStatusChecker(string processName)
        {
            try
            {
                // 실행 중인 프로세스 중에 지정된 이름과 일치하는 것이 있는지 확인
                var isRunning = Process.GetProcessesByName(processName).Length > 0;

                // 결과를 반환하고 로그에 기록
                if (isRunning)
                {
                    _logger.LogInformation($"Process '{processName}' is currently running (ON).");
                    return (true,"ON");
                }
                else
                {
                    _logger.LogWarning($"Process '{processName}' is not running (OFF).");
                    return (true,"OFF");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error checking process '{processName}': {ex.Message}");
                return (false,"OFF");
            }
        }
    }
}
