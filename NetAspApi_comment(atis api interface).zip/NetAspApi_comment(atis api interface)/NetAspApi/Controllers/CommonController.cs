using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Serilog;
using System.Diagnostics;
using System.IO.Pipes;
using System.Reflection.Metadata.Ecma335;
using NetAspApi.Class;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;


namespace NetAspApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CommonController : ControllerBase
    {
        private readonly ILogger<CommonController> _logger;
        private readonly PipeResponseHandler _pipeResponseHandler = new PipeResponseHandler();
        private readonly StatusChecker _statusChecker;

        public CommonController(ILogger<CommonController> logger, StatusChecker statusChecker)
        {
            _logger = logger;
            _statusChecker = statusChecker;
        }

        /// <summary>
        /// Threshold ������Ʈ API
        /// </summary>
        /// <param name="request">��û �Ķ��Ÿ</param>
        /// <returns></returns>
        [HttpPost("/update/threshold")]
        public Task<IActionResult> UpdateThreshold([FromBody] object request)
        {
            return ProcessRequest(request, "update_threshold");
        }

        /// <summary>
        /// Status ��û API
        /// </summary>
        /// <param name="request">��û �Ķ��Ÿ</param>
        /// <returns></returns>
        [HttpPost("/status")]
        public Task<IActionResult> requireStatus([FromBody] object request)
        {
            bool isValid = true;
            string requestData = Convert.ToString(request);

            // Status �κи� Pasing�� �����Ѵ�.
            if (string.IsNullOrEmpty(requestData))
                isValid = false;
            //else 
            //{
            //    if (PipeResponseHandler.IsJson(requestData))
            //    {
            //        // �԰ݿ� �°� Parsing ����
            //        Status reqSts = JsonConvert.DeserializeObject<Status>(requestData);
            //
            //        if (reqSts == null)
            //            isValid = false;
            //        else
            //        {
            //            if (reqSts.STATUS_CODE == null)
            //            {
            //                isValid = false;
            //            }
            //            else
            //            { 
            //                if (reqSts.STATUS_CODE.Count < 1)
            //                    isValid = false;
            //                else
            //                {
            //                    string convertData = JsonConvert.SerializeObject(reqSts.STATUS_CODE).ToString().Replace("[", "{").Replace("]", "}");
            //                    request = convertData;
            //                }
            //            }
            //        }
            //    }
            //    else
            //        isValid = false;
            //}

            return ProcessRequest(request, "status", isValid);
        }

        /// <summary>
        /// Status ��û API
        /// </summary>
        /// <param name="request">��û �Ķ��Ÿ</param>
        /// <returns></returns>
        [HttpPost("/update/model")]
        public Task<IActionResult> UpdateModdel([FromBody] object request)
        {
            return ProcessRequest(request, "update_model");
        }

        /// <summary>
        /// SerivceStatus ��û API
        /// </summary>
        /// <param name="request">��û �Ķ��Ÿ</param>
        /// <returns></returns>
        [HttpGet("/ServiceStatus")]
        public Task<IActionResult> SerivceStatus([FromBody] object? request)
        {
            try
            {
                service_result srvResult = new service_result();

                if (string.IsNullOrEmpty(SetConfig.plcNetNm) || string.IsNullOrEmpty(SetConfig.plcNetNm) || string.IsNullOrEmpty(SetConfig.plcNetNm)
                    || string.IsNullOrEmpty(SetConfig.plcNetNm) || string.IsNullOrEmpty(SetConfig.plcNetNm) || string.IsNullOrEmpty(SetConfig.plcNetNm))
                {
                    _logger.LogCritical($"# Error occured: Status Target Naming Missing");
                    var errorResponse =  _pipeResponseHandler.CreateErrorResponse("52", "Status Target Naming Missing");
                    //srvResult.RESULT_CODE = "EC052";
                    //srvResult.ERROR_DATA = "Status Target Naming Missing";
                    //srvResult.PLC_NET_STS = "OFF";
                    //srvResult.CAM_CA_NET_STS = "OFF";
                    //srvResult.CAM_AN_NET_STS = "OFF";
                    //srvResult.EDGE_PG_RUN_STS = "OFF";
                    //srvResult.VISS_PG_RUN_STS = "OFF";
                    //srvResult.DB_PG_RUN_STS = "OFF";

                    return Task.FromResult<IActionResult>(Content(errorResponse, "application/json; charset=utf-8"));
                }

                // Stat Check Start
                var plc = _statusChecker.NetworkAdapterChecker(SetConfig.plcNetNm);
                var camCa = _statusChecker.NetworkAdapterChecker(SetConfig.camCaNm);
                var camAn = _statusChecker.NetworkAdapterChecker(SetConfig.camAnNm);
                var edge = _statusChecker.ProcessStatusChecker(SetConfig.edgePgNm);
                var viss = _statusChecker.ProcessStatusChecker(SetConfig.vissPgNm);
                var db = _statusChecker.ProcessStatusChecker(SetConfig.dbPgNm);

                srvResult.RESULT_CODE = "OK";
                srvResult.ERROR_DATA = (!plc.Item1 || !camCa.Item1 || !camAn.Item1 || !edge.Item1 || !viss.Item1 || !db.Item1) ? "Error on Status Check" : "";
                srvResult.PLC_NET_STS = plc.Item2;
                srvResult.CAM_CA_NET_STS = camCa.Item2;
                srvResult.CAM_AN_NET_STS = camAn.Item2;
                srvResult.EDGE_PG_RUN_STS = edge.Item2;
                srvResult.VISS_PG_RUN_STS = viss.Item2;
                srvResult.DB_PG_RUN_STS = db.Item2;
                
                return Task.FromResult < IActionResult > (Content(_pipeResponseHandler.jsonSerialize(srvResult), "application/json; charset=utf-8"));
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"# Error occured: {ex.Message}");
                var errorResponse = _pipeResponseHandler.CreateErrorResponse("51", ex.Message);
                return Task.FromResult < IActionResult > (Content(_pipeResponseHandler.jsonSerialize(errorResponse), "application/json; charset=utf-8"));
            }
        }

        /// <summary>
        /// Status ��û API
        /// </summary>
        /// <param name="request">��û �Ķ��Ÿ</param>
        /// <returns></returns>
        [HttpPost("/idmax/testcall")]
        public async Task<IActionResult> testcall([FromBody] object request)
        {
            var jsonResponse = _pipeResponseHandler.ParsePipeResponse($"00|{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");

            return Ok(jsonResponse ?? _pipeResponseHandler.ParsePipeResponse("11|No response Data from Runtime Program:NOT FOUND"));
        }

        /// <summary>
        /// Pipe ����� ���� �����͸� �ְ� �޴� API
        /// </summary>
        /// <param name="request">��û �Ķ����</param>
        /// <param name="triggerType">Ʈ���� Ÿ��</param>
        /// <returns></returns>
        /// 
        [NonAction] //1����������
        public async Task<IActionResult> ProcessRequest([FromBody] object request, string triggerType, bool isValid = true)
        {
            object _req = request;
            NamedPipeClientStream pipeClient = null;
            StreamWriter writer = null;
            StreamReader reader = null;

            string timeoutType = SetConfig.rtnTime; // Runtime PG ��ȯ��� Ÿ�Ӿƿ� �ð�
            string pgTimeout = SetConfig.connTime;  // Runtime PG ���� Ÿ�Ӿƿ� �ð�
            try
            {
                // isValid�� Status ȣ�� �뵵�̴�.
                if (isValid == false)
                    return Content((_pipeResponseHandler.ParsePipeResponse("22|Invalid Parameter")).ToString(), "application/json; charset=utf-8");
                
                pipeClient = new NamedPipeClientStream(".", "pipeRestAPI", PipeDirection.InOut, PipeOptions.Asynchronous);
                
                await pipeClient.ConnectAsync(Convert.ToInt32(pgTimeout)); // ������ N��
            
                writer = new StreamWriter(pipeClient) { AutoFlush = true };
                reader = new StreamReader(pipeClient);
                    
            
                string param = string.Format("{0}|{1}", triggerType, request.ToString());
                _logger.LogInformation("start trigger - {param}", param);
                await writer.WriteLineAsync(param);
                await writer.FlushAsync();
                        
                // ������ (N�� ������ ���� ���, Ÿ�� �ƿ� Message ��ȯ
                var readTask = reader.ReadLineAsync();

                if (triggerType.Equals("update_model"))
                    timeoutType = SetConfig.rtnTimeModel;
                else
                    timeoutType = SetConfig.rtnTime;

                if (await Task.WhenAny(readTask, Task.Delay(Convert.ToInt32(timeoutType))) == readTask)
                {
                    var response = await readTask;
                    _logger.LogInformation("Response Data : {response}.", response);
                
                    // ������ �ݱ� ���� ���� ��ȯ
                    if (!pipeClient.IsConnected)
                    {
                        _logger.LogError("Pipe is closed before reading response.");
                        var errorResponse = _pipeResponseHandler.CreateErrorResponse("41", "Pipe is closed before reading response.");

                        return Content(errorResponse, "application/json; charset=utf-8");
                    }

                    var jsonResponse = _pipeResponseHandler.ParsePipeResponse(response, triggerType);

                    _logger.LogInformation("[Result]" + jsonResponse ?? "No response from Runtime Program");
                    return Content((jsonResponse ?? _pipeResponseHandler.ParsePipeResponse("11|No response Data from Runtime Program:NOT FOUND")).ToString(), "application/json; charset=utf-8");
                }
                else
                {
                    // N�� �� ���� ���ٸ� Ÿ�Ӿƿ� ó��
                    _logger.LogError($"No response from Runtime Program : TimeOut. {timeoutType} ms.");
                    var errorResponse = _pipeResponseHandler.CreateErrorResponse("42", $"Not Response ({timeoutType} ms)");

                    return Content(errorResponse.ToString(), "application/json; charset=utf-8");
                }
            }
            
            catch (TimeoutException)
            {
                _logger.LogError($"Failed to connect Runtime Programs : Timeout. {pgTimeout} ms.");
                var errorResponse = _pipeResponseHandler.CreateErrorResponse("42", $"Not Response ({pgTimeout} ms)");
                return Content(errorResponse.ToString(), "application/json; charset=utf-8");
            }
            catch (IOException ioEx)
            {
                _logger.LogError($"Pipe IO Exception: {ioEx.Message}");
                var errorResponse = _pipeResponseHandler.CreateErrorResponse("43", "Disconnect Runtime");
                return Content(errorResponse.ToString(), "application/json; charset=utf-8");
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"# Error occured: {ex.Message}");
                var errorResponse = _pipeResponseHandler.CreateErrorResponse("41", ex.Message);
                return Content(errorResponse.ToString(), "application/json; charset=utf-8");
            }
            finally
            {
                if (reader != null)
                {
                    try { reader?.Dispose(); }
                    catch { }
                }
                if (writer != null)
                {
                    try { writer?.Dispose(); }
                    catch { }
                }
                if (pipeClient != null)
                {
                    try { pipeClient?.Dispose(); }
                    catch { }
                }
            }
        }
    }
}
